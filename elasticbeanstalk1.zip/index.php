<?php 

echo "Everlasting"
echo "Everything will going on!" 
echo "Great"
error_log("Token error log", 0);
echo "Error logged"