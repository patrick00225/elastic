<?php 

echo "SITE 2.0"
echo "Let's see if it work properly!" 
echo "Great"
error_log("Token error log", 0);
echo "Error logged"